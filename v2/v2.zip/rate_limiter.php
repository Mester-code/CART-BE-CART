<?php
require_once 'config.php';

function checkRateLimit() {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $db = getDB();
    
    $now = time();
    $window = 3600; 
    
    $db->prepare("DELETE FROM rate_limits WHERE reset_time < :now")
       ->execute([':now' => $now]);
    
    $stmt = $db->prepare("SELECT * FROM rate_limits WHERE ip = :ip");
    $stmt->execute([':ip' => $ip]);
    $limit = $stmt->fetch();
    
    if ($limit) {
        if ($now > $limit['reset_time']) {
            $db->prepare("UPDATE rate_limits SET request_count = 1, reset_time = :reset WHERE ip = :ip")
               ->execute([':reset' => $now + $window, ':ip' => $ip]);
        } else {
            $db->prepare("UPDATE rate_limits SET request_count = request_count + 1 WHERE ip = :ip")
               ->execute([':ip' => $ip]);
        }
    } else {
        $db->prepare("INSERT INTO rate_limits (ip, request_count, reset_time) VALUES (:ip, 1, :reset)")
           ->execute([':ip' => $ip, ':reset' => $now + $window]);
    }
    
    $stmt = $db->prepare("SELECT request_count FROM rate_limits WHERE ip = :ip");
    $stmt->execute([':ip' => $ip]);
    $count = $stmt->fetchColumn();
    
    if ($count > RATE_LIMIT_REQUESTS) {
        http_response_code(429);
        echo json_encode(['success' => false, 'error' => 'تعداد درخواست‌های شما بیش از حد مجاز است.']);
        exit;
    }
}