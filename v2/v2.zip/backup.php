<?php
require_once 'config.php';

$isCronJob = php_sapi_name() === 'cli';

if (!$isCronJob) {
    $apiKey = $_REQUEST['api_key'] ?? '';
    if ($apiKey !== API_KEY) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'دسترسی غیرمجاز']);
        exit;
    }
}

$backupDate = date('Y-m-d');
$backupFolder = BACKUP_DIR . '/' . $backupDate;

if (!is_dir(BACKUP_DIR)) {
    mkdir(BACKUP_DIR, 0755, true);
}

if (!is_dir($backupFolder)) {
    mkdir($backupFolder, 0755, true);
}

try {
    $db = getDB();
    
    
    $stmt = $db->query("SELECT * FROM transactions");
    $transactions = $stmt->fetchAll();
    file_put_contents(
        $backupFolder . '/transactions.json',
        json_encode(['transactions' => $transactions], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
    

    $stmt = $db->query("SELECT * FROM messages");
    $messages = $stmt->fetchAll();
    file_put_contents(
        $backupFolder . '/messages.json',
        json_encode(['messages' => $messages], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
    

    $stmt = $db->query("SELECT * FROM cards");
    $cards = $stmt->fetchAll();
    file_put_contents(
        $backupFolder . '/cards.json',
        json_encode(['cards' => $cards], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
    

    $retentionDays = 30;
    $cutoffTime = time() - ($retentionDays * 86400);
    $dirs = scandir(BACKUP_DIR);
    
    foreach ($dirs as $dir) {
        if ($dir === '.' || $dir === '..') continue;
        
        $dirPath = BACKUP_DIR . '/' . $dir;
        if (is_dir($dirPath) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dir)) {
            $dirTime = strtotime($dir);
            
            if ($dirTime !== false && $dirTime < $cutoffTime) {
                $files = scandir($dirPath);
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..') {
                        @unlink($dirPath . '/' . $file);
                    }
                }
                @rmdir($dirPath);
            }
        }
    }
    
    $message = "بکاپ {$backupDate} با موفقیت انجام شد";
    
    if (!$isCronJob) {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'stats' => [
                'transactions' => count($transactions),
                'messages' => count($messages),
                'cards' => count($cards)
            ]
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}