<?php
session_start();
require_once 'config.php';

// ==========================================
// 🔐 احراز هویت ادمین
// ==========================================
if (isset($_POST['admin_pass']) && $_POST['admin_pass'] === ADMIN_PASSWORD) {
    $_SESSION['admin'] = true;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['admin'])) {
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>ورود به پنل مدیریت</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
        <style>body { font-family: 'Vazirmatn', Tahoma, sans-serif; }</style>
    </head>
    <body class="bg-gradient-to-br from-blue-500 to-purple-600 min-h-screen flex items-center justify-center p-4">
        <form method="POST" class="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md">
            <div class="text-center mb-6">
                <div class="text-5xl mb-3 ">  NET VISIT  </div>
                <h1 class="text-2xl font-black text-gray-800"> چطوری! </h1>
                <p class="text-gray-500 text-sm mt-2">لطفاً رمز عبور را وارد کنید</p>
            </div>
            <input type="password" name="admin_pass" placeholder="رمز عبور" class="w-full p-4 border-2 border-gray-200 rounded-xl mb-4 focus:border-blue-500 outline-none text-center text-lg" autofocus required>
            <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-xl font-bold hover:opacity-90 transition">ورود به پنل</button>
        </form>
    </body>
    </html>
    <?php
    exit;
}

try {
    $pdo = getDB();
} catch (Exception $e) {
    die('خطا در اتصال به دیتابیس: ' . $e->getMessage());
}


$today = date('Y-m-d');
$weekStart = date('Y-m-d', strtotime('-7 days'));
$monthStart = date('Y-m-d', strtotime('-30 days'));


$stmt = $pdo->prepare("
    SELECT 
        COUNT(CASE WHEN status = 'paid' AND DATE(paid_at) = :today1 THEN 1 END) as today_count,
        COALESCE(SUM(CASE WHEN status = 'paid' AND DATE(paid_at) = :today2 THEN base_amount_rial/10 ELSE 0 END), 0) as today_amount,
        COUNT(CASE WHEN status = 'paid' AND DATE(paid_at) >= :week_start1 THEN 1 END) as week_count,
        COALESCE(SUM(CASE WHEN status = 'paid' AND DATE(paid_at) >= :week_start2 THEN base_amount_rial/10 ELSE 0 END), 0) as week_amount,
        COUNT(CASE WHEN status = 'paid' AND DATE(paid_at) >= :month_start1 THEN 1 END) as month_count,
        COALESCE(SUM(CASE WHEN status = 'paid' AND DATE(paid_at) >= :month_start2 THEN base_amount_rial/10 ELSE 0 END), 0) as month_amount,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
        COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count,
        COUNT(CASE WHEN status = 'expired' THEN 1 END) as expired_count
    FROM transactions
");
$stmt->execute([
    ':today1' => $today,
    ':today2' => $today,
    ':week_start1' => $weekStart,
    ':week_start2' => $weekStart,
    ':month_start1' => $monthStart,
    ':month_start2' => $monthStart
]);
$stats = $stmt->fetch();

$stmt = $pdo->query("SELECT COUNT(*) FROM messages WHERE verify = 0 AND is_deposit = 1");
$stats['unmatched_messages'] = $stmt->fetchColumn();

$cards = getCards();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'add_card':
                $newCard = [
                    'id' => 'c' . time(),
                    'number' => preg_replace('/[^0-9]/', '', $_POST['number'] ?? ''),
                    'bank' => trim($_POST['bank'] ?? ''),
                    'owner' => trim($_POST['owner'] ?? '')
                ];
                
                if (strlen($newCard['number']) !== 16) {
                    throw new Exception('شماره کارت باید ۱۶ رقم باشد');
                }
                if (empty($newCard['bank']) || empty($newCard['owner'])) {
                    throw new Exception('تمام فیلدها الزامی است');
                }
                
                $stmt = $pdo->prepare("INSERT INTO cards (id, number, bank, owner) VALUES (:id, :number, :bank, :owner)");
                $stmt->execute($newCard);
                
                $message = '✅ کارت جدید با موفقیت اضافه شد';
                $messageType = 'success';
                break;
            
            case 'remove_card':
                $cardId = $_POST['card_id'] ?? '';
                $stmt = $pdo->prepare("DELETE FROM cards WHERE id = :id");
                $stmt->execute([':id' => $cardId]);
                
                $message = '✅ کارت با موفقیت حذف شد';
                $messageType = 'success';
                break;
            
            case 'manual_match':
                $txId = $_POST['tx_id'] ?? '';
                $msgId = $_POST['msg_id'] ?? '';
                
                if ($txId && $msgId) {
                    $pdo->beginTransaction();
                    
                    $stmt = $pdo->prepare("
                        UPDATE transactions 
                        SET status = 'paid',
                            paid_at = NOW(),
                            matched_msg_id = :msg_id,
                            manual_match = 1
                        WHERE id = :tx_id
                    ");
                    $stmt->execute([':msg_id' => $msgId, ':tx_id' => $txId]);
                    
                    $stmt = $pdo->prepare("
                        UPDATE messages 
                        SET verify = 1,
                            matched_hangt_id = :tx_id
                        WHERE msg_id = :msg_id
                    ");
                    $stmt->execute([':tx_id' => $txId, ':msg_id' => $msgId]);
                    
                    $pdo->commit();
                    
                    $message = '✅ تراکنش با موفقیت مچ شد';
                    $messageType = 'success';
                }
                break;
            
            case 'create_transaction':
                $chatId = trim($_POST['chat_id'] ?? '');
                $name = trim($_POST['name'] ?? '');
                $amount = (int)($_POST['amount'] ?? 0);
                $type = $_POST['type'] ?? 'rial';
                $callbackUrl = trim($_POST['callback_url'] ?? '');
                
                if (empty($chatId) || empty($name) || $amount <= 0) {
                    throw new Exception('لطفاً تمام فیلدها را به درستی پر کنید');
                }
                
                if (empty($cards)) {
                    throw new Exception('هیچ کارتی تعریف نشده است. ابتدا از بخش "کارت‌ها" یک کارت اضافه کنید.');
                }
                
                $amountRial = ($type === 'tmn') ? $amount * 10 : $amount;
                $selectedCard = $cards[array_rand($cards)];
                
                $trackingCode = rand(1, 9999);
                $finalAmountRial = $amountRial + $trackingCode;
                $txId = 'TX_' . time() . '_' . rand(1000, 9999);
                
                $stmt = $pdo->prepare("
                    INSERT INTO transactions (
                        id, chat_id, name, base_amount_rial, final_amount_rial,
                        card_number, card_bank, card_owner, status, created_at,
                        expires_at, callback_url, phone_verified, created_by
                    ) VALUES (
                        :id, :chat_id, :name, :base_amount_rial, :final_amount_rial,
                        :card_number, :card_bank, :card_owner, 'pending', NOW(),
                        DATE_ADD(NOW(), INTERVAL 1 HOUR), :callback_url, 0, 'admin'
                    )
                ");
                
                $stmt->execute([
                    ':id' => $txId,
                    ':chat_id' => $chatId,
                    ':name' => $name,
                    ':base_amount_rial' => $amountRial,
                    ':final_amount_rial' => $finalAmountRial,
                    ':card_number' => $selectedCard['number'],
                    ':card_bank' => $selectedCard['bank'],
                    ':card_owner' => $selectedCard['owner'],
                    ':callback_url' => $callbackUrl ?: null
                ]);
                
                $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
                $host = $_SERVER['HTTP_HOST'];
                $path = dirname($_SERVER['SCRIPT_NAME']);
                $paymentUrl = "{$protocol}://{$host}{$path}/pay.php?id=" . urlencode($txId);
                
                $message = "✅ تراکنش ایجاد شد. مبلغ: <strong>" . number_format($finalAmountRial) . " ریال</strong> | <a href='{$paymentUrl}' target='_blank' class='underline font-bold'>🔗 مشاهده صفحه پرداخت</a>";
                $messageType = 'success';
                break;
            
            case 'update_settings':
                $configFile = __DIR__ . '/config.php';
                $configContent = file_get_contents($configFile);
                
                @copy($configFile, $configFile . '.backup.' . time());
                
                $updates = [
                    'API_KEY' => ['type' => 'string', 'value' => trim($_POST['API_KEY'] ?? '')],
                    'SMS_TOKEN' => ['type' => 'string', 'value' => trim($_POST['SMS_TOKEN'] ?? '')],
                    'OTP_THRESHOLD_TOMAN' => ['type' => 'int', 'value' => (int)($_POST['OTP_THRESHOLD_TOMAN'] ?? 500000)],
                    'RATE_LIMIT_REQUESTS' => ['type' => 'int', 'value' => (int)($_POST['RATE_LIMIT_REQUESTS'] ?? 100)],
                    'WEBHOOK_TIMEOUT' => ['type' => 'int', 'value' => (int)($_POST['WEBHOOK_TIMEOUT'] ?? 5)],
                ];
                
                foreach ($updates as $key => $cfg) {
                    if ($cfg['type'] === 'string') {
                        $escaped = addslashes($cfg['value']);
                        $pattern = "/define\\(\\s*['\"]{$key}['\"]\\s*,\\s*['\"][^'\"]*['\"]\\s*\\)\\s*;/";
                        $replacement = "define('{$key}', '{$escaped}');";
                    } else {
                        $pattern = "/define\\(\\s*['\"]{$key}['\"]\\s*,\\s*[^;]+\\)\\s*;/";
                        $replacement = "define('{$key}', {$cfg['value']});";
                    }
                    
                    $newContent = preg_replace($pattern, $replacement, $configContent, -1, $count);
                    if ($count > 0) {
                        $configContent = $newContent;
                    }
                }
                
                if (file_put_contents($configFile, $configContent) === false) {
                    throw new Exception('خطا در ذخیره تنظیمات. دسترسی نوشتن را بررسی کنید.');
                }
                
                $message = '✅ تنظیمات ذخیره شد. برای اعمال، یک بار از پنل خارج و مجدداً وارد شوید.';
                $messageType = 'success';
                break;
            
            case 'change_password':
                $newPassword = $_POST['new_password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';
                
                if (strlen($newPassword) < 6) {
                    throw new Exception('رمز عبور باید حداقل ۶ کاراکتر باشد');
                }
                if ($newPassword !== $confirmPassword) {
                    throw new Exception('رمز عبور و تکرار آن مطابقت ندارند');
                }
                
                $configFile = __DIR__ . '/config.php';
                $configContent = file_get_contents($configFile);
                
                @copy($configFile, $configFile . '.backup.' . time());
                
                $escaped = addslashes($newPassword);
                $pattern = "/define\\(\\s*['\"]ADMIN_PASSWORD['\"]\\s*,\\s*['\"][^'\"]*['\"]\\s*\\)\\s*;/";
                $replacement = "define('ADMIN_PASSWORD', '{$escaped}');";
                $configContent = preg_replace($pattern, $replacement, $configContent);
                
                if (file_put_contents($configFile, $configContent) === false) {
                    throw new Exception('خطا در تغییر رمز عبور');
                }
                
                $message = '✅ رمز عبور تغییر کرد';
                $messageType = 'success';
                break;
        }
    } catch (Exception $e) {
        $message = '❌ ' . $e->getMessage();
        $messageType = 'error';
    }
    
    header('Location: admin.php?tab=' . ($_POST['tab'] ?? 'dashboard') . '&msg=' . urlencode($message) . '&type=' . $messageType);
    exit;
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $messageType = $_GET['type'] ?? 'info';
}

$currentTab = $_GET['tab'] ?? 'dashboard';
$baseUrl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']);


$stmt = $pdo->query("SELECT * FROM transactions ORDER BY created_at DESC LIMIT 10");
$recentTxs = $stmt->fetchAll();


$stmt = $pdo->query("SELECT * FROM transactions ORDER BY created_at DESC");
$allTxs = $stmt->fetchAll();


$stmt = $pdo->query("SELECT * FROM messages WHERE verify = 0 AND is_deposit = 1 ORDER BY received_at DESC");
$unmatchedMessages = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل‌مدیریت کارت به کارت هوشمند نت ویزیت</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
    <style>
        body { font-family: 'Vazirmatn', Tahoma, sans-serif; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .tab-btn.active { background: white; color: #3b82f6; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .copy-btn { transition: all 0.2s; }
        .copy-btn.copied { background: #10b981 !important; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="max-w-7xl mx-auto p-4 md:p-8">
        
        
        <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-2xl shadow-lg mb-6">
            <div class="flex justify-between items-center flex-wrap gap-4">
                <div>
                    <h1 class="text-2xl md:text-3xl font-black">📊 پنل مدیریت حرفه‌ای</h1>
                    <p class="text-blue-100 text-sm mt-1">نسخه ۲.۰ - سیستم پرداخت خودکار (MySQL)</p>
                </div>
                <a href="?logout=1" class="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-bold transition backdrop-blur">
                    🚪 خروج
                </a>
            </div>
        </div>

        
        <?php if ($message): ?>
        <div class="mb-6 p-4 rounded-xl <?php echo $messageType === 'success' ? 'bg-green-50 border-r-4 border-green-500 text-green-800' : ($messageType === 'error' ? 'bg-red-50 border-r-4 border-red-500 text-red-800' : 'bg-blue-50 border-r-4 border-blue-500 text-blue-800'); ?>">
            <?php echo $message; ?>
        </div>
        <?php endif; ?>

        
        <div class="bg-white rounded-2xl shadow-sm mb-6 p-2 flex flex-wrap gap-2">
            <button onclick="showTab('dashboard')" class="tab-btn active px-4 py-2 rounded-lg font-bold text-sm transition" data-tab="dashboard">📊 داشبورد</button>
            <button onclick="showTab('create')" class="tab-btn px-4 py-2 rounded-lg font-bold text-sm transition hover:bg-gray-100" data-tab="create">➕ ساخت تراکنش</button>
            <button onclick="showTab('cards')" class="tab-btn px-4 py-2 rounded-lg font-bold text-sm transition hover:bg-gray-100" data-tab="cards">💳 کارت‌ها</button>
            <button onclick="showTab('transactions')" class="tab-btn px-4 py-2 rounded-lg font-bold text-sm transition hover:bg-gray-100" data-tab="transactions">🔄 تراکنش‌ها</button>
            <button onclick="showTab('settings')" class="tab-btn px-4 py-2 rounded-lg font-bold text-sm transition hover:bg-gray-100" data-tab="settings">⚙️ تنظیمات</button>
        </div>

        <div id="tab-dashboard" class="tab-content active">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div class="bg-white p-6 rounded-2xl shadow-sm border-r-4 border-green-500">
                    <h3 class="text-gray-500 text-sm font-bold mb-2">📅 واریزی‌های امروز</h3>
                    <p class="text-3xl font-black text-green-600"><?php echo $stats['today_count']; ?></p>
                    <p class="text-sm font-bold text-gray-700 mt-1"><?php echo number_format($stats['today_amount']); ?> تومان</p>
                </div>
                <div class="bg-white p-6 rounded-2xl shadow-sm border-r-4 border-blue-500">
                    <h3 class="text-gray-500 text-sm font-bold mb-2">📆 این هفته</h3>
                    <p class="text-3xl font-black text-blue-600"><?php echo $stats['week_count']; ?></p>
                    <p class="text-sm font-bold text-gray-700 mt-1"><?php echo number_format($stats['week_amount']); ?> تومان</p>
                </div>
                <div class="bg-white p-6 rounded-2xl shadow-sm border-r-4 border-purple-500">
                    <h3 class="text-gray-500 text-sm font-bold mb-2">🗓️ این ماه</h3>
                    <p class="text-3xl font-black text-purple-600"><?php echo $stats['month_count']; ?></p>
                    <p class="text-sm font-bold text-gray-700 mt-1"><?php echo number_format($stats['month_amount']); ?> تومان</p>
                </div>
                <div class="bg-white p-6 rounded-2xl shadow-sm border-r-4 border-yellow-500">
                    <h3 class="text-gray-500 text-sm font-bold mb-2">⏳ وضعیت تراکنش‌ها</h3>
                    <p class="text-sm text-gray-600">در انتظار: <span class="font-bold text-yellow-600"><?php echo $stats['pending_count']; ?></span></p>
                    <p class="text-sm text-gray-600">موفق: <span class="font-bold text-green-600"><?php echo $stats['paid_count']; ?></span></p>
                    <p class="text-sm text-gray-600">نامچ: <span class="font-bold text-orange-600"><?php echo $stats['unmatched_messages']; ?></span></p>
                </div>
            </div>

            <div class="bg-white p-6 rounded-2xl shadow-sm">
                <h2 class="text-xl font-black mb-4">📈 آخرین تراکنش‌ها</h2>
                <?php if (empty($recentTxs)): ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="text-5xl mb-3">📭</div>
                    <p>هنوز تراکنشی ثبت نشده است</p>
                </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-3 text-right">آیدی</th>
                                <th class="p-3 text-right">کاربر</th>
                                <th class="p-3 text-right">مبلغ (ریال)</th>
                                <th class="p-3 text-right">وضعیت</th>
                                <th class="p-3 text-right">تاریخ</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php foreach ($recentTxs as $tx): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-3 font-mono text-xs"><?php echo substr($tx['id'], -10); ?></td>
                                <td class="p-3"><?php echo htmlspecialchars($tx['name']); ?></td>
                                <td class="p-3 font-bold"><?php echo number_format($tx['final_amount_rial']); ?></td>
                                <td class="p-3">
                                    <span class="px-2 py-1 rounded-full text-xs font-bold 
                                        <?php echo $tx['status'] === 'paid' ? 'bg-green-100 text-green-700' : ($tx['status'] === 'expired' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'); ?>">
                                        <?php echo $tx['status'] === 'paid' ? 'پرداخت شده' : ($tx['status'] === 'expired' ? 'منقضی' : 'در انتظار'); ?>
                                    </span>
                                </td>
                                <td class="p-3 text-xs text-gray-500"><?php echo $tx['created_at']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div id="tab-create" class="tab-content">
            <?php if (empty($cards)): ?>
            <div class="bg-yellow-50 border-r-4 border-yellow-500 p-6 rounded-xl mb-6">
                <h3 class="font-bold text-yellow-800 mb-2">⚠️ هشدار: هیچ کارتی تعریف نشده است</h3>
                <p class="text-yellow-700 text-sm">قبل از ساخت تراکنش، باید حداقل یک کارت بانکی در بخش "کارت‌ها" اضافه کنید.</p>
                <button onclick="showTab('cards')" class="mt-3 bg-yellow-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-yellow-700 transition">➕ رفتن به بخش کارت‌ها</button>
            </div>
            <?php endif; ?>
            
            <div class="bg-white p-6 rounded-2xl shadow-sm">
                <h2 class="text-xl font-black mb-4">➕ ساخت تراکنش جدید</h2>
                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="hidden" name="action" value="create_transaction">
                    <input type="hidden" name="tab" value="create">
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">آیدی کاربر (Chat ID)</label>
                        <input type="text" name="chat_id" required class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none" placeholder="مثلاً: 123456789">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">نام کاربر</label>
                        <input type="text" name="name" required class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none" placeholder="مثلاً: علی محمدی">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">مبلغ (ریال یا تومان)</label>
                        <input type="number" name="amount" required min="1000" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none" placeholder="مثلاً: 50000">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">واحد مبلغ</label>
                        <select name="type" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none">
                            <option value="rial">ریال</option>
                            <option value="tmn">تومان</option>
                        </select>
                    </div>
                    
                    <div class="md:col-span-2">
                        <label class="block text-sm font-bold text-gray-700 mb-2">آدرس Callback (اختیاری)</label>
                        <input type="url" name="callback_url" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none" placeholder="https://yourwebsite.com/webhook" dir="ltr">
                        <p class="text-xs text-gray-500 mt-1">پس از پرداخت موفق، اطلاعات به این آدرس POST می‌شود</p>
                    </div>
                    
                    <div class="md:col-span-2">
                        <button type="submit" <?php echo empty($cards) ? 'disabled' : ''; ?> class="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white p-4 rounded-xl font-bold hover:opacity-90 transition text-lg disabled:opacity-50 disabled:cursor-not-allowed">
                             ساخت تراکنش
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div id="tab-cards" class="tab-content">
            <div class="bg-white p-6 rounded-2xl shadow-sm mb-6">
                <h2 class="text-xl font-black mb-4">💳 افزودن کارت جدید</h2>
                <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <input type="hidden" name="action" value="add_card">
                    <input type="hidden" name="tab" value="cards">
                    <input type="text" name="number" placeholder="شماره کارت (۱۶ رقم)" class="border-2 p-3 rounded-lg focus:border-blue-500 outline-none" required maxlength="19" inputmode="numeric">
                    <input type="text" name="bank" placeholder="نام بانک (مثلاً: بلو بانک)" class="border-2 p-3 rounded-lg focus:border-blue-500 outline-none" required>
                    <input type="text" name="owner" placeholder="نام صاحب حساب" class="border-2 p-3 rounded-lg focus:border-blue-500 outline-none" required>
                    <button type="submit" class="bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 font-bold transition">➕ افزودن</button>
                </form>
            </div>

            <div class="bg-white p-6 rounded-2xl shadow-sm">
                <h2 class="text-xl font-black mb-4">📋 لیست کارت‌ها (<?php echo count($cards); ?> کارت)</h2>
                <?php if (empty($cards)): ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="text-5xl mb-3">💳</div>
                    <p>هنوز کارتی اضافه نشده است</p>
                </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-3 text-right">شماره کارت</th>
                                <th class="p-3 text-right">نام بانک ( هنوز ققط بلو )</th>
                                <th class="p-3 text-right">صاحب</th>
                                <th class="p-3 text-right">عملیات</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php foreach ($cards as $card): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-3 font-mono font-bold"><?php echo chunk_split($card['number'], 4, ' - '); ?></td>
                                <td class="p-3">
                                    <?php echo htmlspecialchars($card['bank']); ?>
                                    <?php if (stripos($card['bank'], 'بلو') === false && stripos($card['bank'], 'blu') === false): ?>
                                        <span class="bg-red-100 text-red-700 text-xs px-2 py-1 rounded-full mr-2 font-bold">⚠️ فقط بلو</span>
                                    <?php else: ?>
                                        <span class="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full mr-2 font-bold">✅ بلو</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-3"><?php echo htmlspecialchars($card['owner']); ?></td>
                                <td class="p-3">
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="action" value="remove_card">
                                        <input type="hidden" name="tab" value="cards">
                                        <input type="hidden" name="card_id" value="<?php echo $card['id']; ?>">
                                        <button type="submit" onclick="return confirm('آیا مطمئن هستید؟')" class="text-red-600 hover:text-red-800 font-bold bg-red-50 px-3 py-1 rounded-lg hover:bg-red-100 transition">🗑️ حذف</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div id="tab-transactions" class="tab-content">
            <div class="bg-white p-6 rounded-2xl shadow-sm">
                <h2 class="text-xl font-black mb-4">🔄 مدیریت و مچ دستی تراکنش‌ها</h2>
                <?php if (empty($allTxs)): ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="text-5xl mb-3">📭</div>
                    <p>هنوز تراکنشی ثبت نشده است</p>
                </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-3 text-right">آیدی</th>
                                <th class="p-3 text-right">کاربر</th>
                                <th class="p-3 text-right">مبلغ (ریال)</th>
                                <th class="p-3 text-right">وضعیت</th>
                                <th class="p-3 text-right">لینک پرداخت</th>
                                <th class="p-3 text-right">مچ دستی</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php foreach ($allTxs as $tx): 
                                $paymentLink = $baseUrl . '/pay.php?id=' . urlencode($tx['id']);
                            ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-3 font-mono text-xs"><?php echo substr($tx['id'], -10); ?></td>
                                <td class="p-3">
                                    <div class="font-bold"><?php echo htmlspecialchars($tx['name']); ?></div>
                                    <div class="text-xs text-gray-500">ID: <?php echo htmlspecialchars($tx['chat_id']); ?></div>
                                </td>
                                <td class="p-3">
                                    <div class="font-bold"><?php echo number_format($tx['final_amount_rial']); ?></div>
                                    <div class="text-xs text-gray-500">پایه: <?php echo number_format($tx['base_amount_rial']); ?></div>
                                </td>
                                <td class="p-3">
                                    <span class="px-2 py-1 rounded-full text-xs font-bold 
                                        <?php echo $tx['status'] === 'paid' ? 'bg-green-100 text-green-700' : ($tx['status'] === 'expired' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'); ?>">
                                        <?php echo $tx['status'] === 'paid' ? '✅ پرداخت شده' : ($tx['status'] === 'expired' ? '❌ منقضی' : '⏳ در انتظار'); ?>
                                    </span>
                                </td>
                                <td class="p-3">
                                    <div class="flex items-center gap-1">
                                        <input type="text" value="<?php echo htmlspecialchars($paymentLink); ?>" 
                                               id="link-<?php echo $tx['id']; ?>" 
                                               readonly 
                                               class="text-xs bg-gray-100 border rounded px-2 py-1 w-40 font-mono" 
                                               dir="ltr"
                                               onclick="this.select()">
                                        <button onclick="copyLink('<?php echo $tx['id']; ?>', this)" 
                                                class="copy-btn bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold hover:bg-blue-700 transition whitespace-nowrap">
                                            📋 کپی
                                        </button>
                                        <a href="<?php echo htmlspecialchars($paymentLink); ?>" target="_blank" 
                                           class="bg-gray-600 text-white px-2 py-1 rounded text-xs font-bold hover:bg-gray-700 transition">
                                            🔗
                                        </a>
                                    </div>
                                </td>
                                <td class="p-3">
                                    <?php if ($tx['status'] === 'pending'): ?>
                                    <form method="POST" class="flex gap-2">
                                        <input type="hidden" name="action" value="manual_match">
                                        <input type="hidden" name="tab" value="transactions">
                                        <input type="hidden" name="tx_id" value="<?php echo $tx['id']; ?>">
                                        <select name="msg_id" class="border p-2 rounded-lg text-xs flex-1">
                                            <option value="">انتخاب پیامک...</option>
                                            <?php foreach ($unmatchedMessages as $msg): ?>
                                                <option value="<?php echo $msg['msg_id']; ?>">
                                                    <?php echo number_format($msg['amount_rial']); ?> ریال
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button type="submit" class="bg-indigo-600 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-indigo-700 transition">🔗 مچ</button>
                                    </form>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs">مچ شده</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div id="tab-settings" class="tab-content">
            <div class="bg-white p-6 rounded-2xl shadow-sm mb-6">
                <h2 class="text-xl font-black mb-4">⚙️ تنظیمات سیستم</h2>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="update_settings">
                    <input type="hidden" name="tab" value="settings">
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">🔑 API Key</label>
                        <div class="flex gap-2">
                            <input type="text" name="API_KEY" value="<?php echo htmlspecialchars(API_KEY); ?>" class="flex-1 p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none font-mono text-sm" dir="ltr">
                            <button type="button" onclick="generateApiKey()" class="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300 transition font-bold text-sm whitespace-nowrap">🎲 تولید</button>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">📱 توکن پیامک (net-visit)</label>
                        <input type="text" name="SMS_TOKEN" value="<?php echo htmlspecialchars(SMS_TOKEN); ?>" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none font-mono text-sm" dir="ltr">
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">💰 آستانه OTP (تومان)</label>
                            <input type="number" name="OTP_THRESHOLD_TOMAN" value="<?php echo OTP_THRESHOLD_TOMAN; ?>" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none">
                            <p class="text-xs text-gray-500 mt-1">مبالغ بالاتر نیاز به تایید پیامکی دارند</p>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">🚦 محدودیت درخواست در ساعت</label>
                            <input type="number" name="RATE_LIMIT_REQUESTS" value="<?php echo RATE_LIMIT_REQUESTS; ?>" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">⏱️ Timeout وب‌هوک (ثانیه)</label>
                            <input type="number" name="WEBHOOK_TIMEOUT" value="<?php echo WEBHOOK_TIMEOUT; ?>" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none">
                        </div>
                    </div>
                    
                    <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-xl font-bold hover:opacity-90 transition">
                        💾 ذخیره تنظیمات
                    </button>
                </form>
            </div>

            <div class="bg-white p-6 rounded-2xl shadow-sm">
                <h2 class="text-xl font-black mb-4">🔐 تغییر رمز عبور ادمین</h2>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="change_password">
                    <input type="hidden" name="tab" value="settings">
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">رمز عبور جدید</label>
                        <input type="password" name="new_password" required minlength="6" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">تکرار رمز عبور</label>
                        <input type="password" name="confirm_password" required minlength="6" class="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none">
                    </div>
                    
                    <button type="submit" class="w-full bg-gradient-to-r from-red-600 to-pink-600 text-white p-4 rounded-xl font-bold hover:opacity-90 transition">
                        🔑 تغییر رمز عبور
                    </button>
                </form>
            </div>
        </div>

    </div>

    <!-- Toast Notification -->
    <div id="toast" class="fixed bottom-5 left-5 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg transform translate-y-20 opacity-0 transition-all duration-300 z-50 font-bold">
        ✅ لینک پرداخت کپی شد!
    </div>

    <script>
        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
            
            document.getElementById('tab-' + tabName).classList.add('active');
            document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
            
            const url = new URL(window.location);
            url.searchParams.set('tab', tabName);
            window.history.pushState({}, '', url);
        }

        function generateApiKey() {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
            let result = '';
            for (let i = 0; i < 48; i++) {
                result += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            document.querySelector('input[name="API_KEY"]').value = result;
        }

        function copyLink(txId, button) {
            const input = document.getElementById('link-' + txId);
            const link = input.value;
            
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(link).then(() => {
                    showCopyFeedback(button);
                }).catch(() => {
                    fallbackCopy(input, button);
                });
            } else {
                fallbackCopy(input, button);
            }
        }

        function fallbackCopy(input, button) {
            input.select();
            input.setSelectionRange(0, 99999);
            try {
                document.execCommand('copy');
                showCopyFeedback(button);
            } catch (err) {
                alert('خطا در کپی. لطفاً دستی کپی کنید.');
            }
        }

        function showCopyFeedback(button) {
            const originalText = button.innerHTML;
            button.innerHTML = '✅ کپی شد';
            button.classList.add('copied');
            
            const toast = document.getElementById('toast');
            toast.classList.remove('translate-y-20', 'opacity-0');
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.classList.remove('copied');
                toast.classList.add('translate-y-20', 'opacity-0');
            }, 2000);
        }

        const urlParams = new URLSearchParams(window.location.search);
        const tabFromUrl = urlParams.get('tab');
        if (tabFromUrl) {
            showTab(tabFromUrl);
        }
    </script>
</body>
</html>