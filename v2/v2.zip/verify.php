<?php
// فعال کردن نمایش خطاها برای دیباگ
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

try {
    require_once 'config.php';
    
    $hangtId = trim($_REQUEST['hangt_id'] ?? '');
    $apiKey = $_REQUEST['api_key'] ?? '';
    
   if (empty($hangtId) || empty($apiKey)) {
        echo json_encode(['success' => false, 'error' => 'پارامترها ناقص هستند']);
        exit;
    }
    
   if ($apiKey !== API_KEY) {
        echo json_encode(['success' => false, 'error' => 'API Key نامعتبر است']);
        exit;
    }
    
    $pdo = getDB();
 $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = :id");
    $stmt->execute([':id' => $hangtId]);
    $tx = $stmt->fetch();
    
    if (!$tx) {
        echo json_encode(['success' => false, 'error' => 'تراکنش یافت نشد']);
        exit;
    }
    if ($tx['status'] === 'paid') {
        echo json_encode([
            'success' => true,
            'status' => 'paid',
            'message' => 'قبلاً تایید شده',
            'callback_url' => $tx['callback_url'] ?? ''
        ]);
        exit;
    }
    

    if (strtotime($tx['expires_at']) < time()) {
        $pdo->prepare("UPDATE transactions SET status = 'expired' WHERE id = :id")
            ->execute([':id' => $hangtId]);
        
        echo json_encode([
            'success' => true,
            'status' => 'expired',
            'message' => 'منقضی شده'
        ]);
        exit;
    }
    

    $stmt = $pdo->prepare("
        SELECT msg_id FROM messages 
        WHERE verify = 0 
          AND is_deposit = 1 
          AND amount_rial = :amount
        LIMIT 1
    ");
    
    $stmt->execute([':amount' => (int)$tx['final_amount_rial']]);
    $msg = $stmt->fetch();
    
    if ($msg) {
        
        $pdo->beginTransaction();
        
        $pdo->prepare("
            UPDATE transactions 
            SET status = 'paid', paid_at = NOW(), matched_msg_id = :msg_id
            WHERE id = :tx_id
        ")->execute([':msg_id' => $msg['msg_id'], ':tx_id' => $hangtId]);
        
        $pdo->prepare("
            UPDATE messages 
            SET verify = 1, matched_hangt_id = :tx_id
            WHERE msg_id = :msg_id
        ")->execute([':tx_id' => $hangtId, ':msg_id' => $msg['msg_id']]);
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'status' => 'paid',
            'message' => 'تایید شد',
            'callback_url' => $tx['callback_url'] ?? ''
        ]);
        exit;
    }
    

    echo json_encode([
        'success' => true,
        'status' => 'pending',
        'message' => 'هنوز واریزی ثبت نشده'
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'خطا: ' . $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
}