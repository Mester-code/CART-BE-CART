<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $db = getDB();
    
    $db->exec("
        CREATE TABLE IF NOT EXISTS transactions (
            id VARCHAR(50) PRIMARY KEY,
            chat_id VARCHAR(50) NOT NULL,
            name VARCHAR(255) NOT NULL,
            base_amount_rial BIGINT NOT NULL,
            final_amount_rial BIGINT NOT NULL,
            card_number VARCHAR(20) NOT NULL,
            card_bank VARCHAR(100) NOT NULL,
            card_owner VARCHAR(255) NOT NULL,
            status ENUM('pending', 'paid', 'expired') DEFAULT 'pending',
            created_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            paid_at DATETIME NULL,
            matched_msg_id VARCHAR(50) NULL,
            callback_url TEXT NULL,
            phone_verified TINYINT(1) DEFAULT 0,
            user_mobile VARCHAR(20) NULL,
            manual_match TINYINT(1) DEFAULT 0,
            created_by VARCHAR(50) DEFAULT 'api',
            payer_ip VARCHAR(45) NULL,
            payer_user_agent TEXT NULL,
            INDEX idx_status (status),
            INDEX idx_expires_at (expires_at),
            INDEX idx_chat_id (chat_id),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    
    $db->exec("
        CREATE TABLE IF NOT EXISTS messages (
            msg_id VARCHAR(50) PRIMARY KEY,
            raw_body TEXT NOT NULL,
            amount_rial BIGINT NOT NULL,
            time VARCHAR(10) NOT NULL,
            date VARCHAR(20) NOT NULL,
            is_deposit TINYINT(1) DEFAULT 1,
            verify TINYINT(1) DEFAULT 0,
            received_at DATETIME NOT NULL,
            matched_hangt_id VARCHAR(50) NULL,
            INDEX idx_verify (verify),
            INDEX idx_is_deposit (is_deposit),
            INDEX idx_amount_rial (amount_rial)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    
    
    $db->exec("
        CREATE TABLE IF NOT EXISTS cards (
            id VARCHAR(50) PRIMARY KEY,
            number VARCHAR(20) NOT NULL,
            bank VARCHAR(100) NOT NULL,
            owner VARCHAR(255) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_bank (bank)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    
    $db->exec("
        CREATE TABLE IF NOT EXISTS rate_limits (
            ip VARCHAR(45) PRIMARY KEY,
            request_count INT DEFAULT 0,
            reset_time INT NOT NULL,
            INDEX idx_reset_time (reset_time)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    
    $db->exec("
        CREATE TABLE IF NOT EXISTS settings (
            setting_key VARCHAR(100) PRIMARY KEY,
            setting_value TEXT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS otp_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            mobile VARCHAR(20) NOT NULL,
            ip VARCHAR(45) NOT NULL,
            attempt_time DATETIME NOT NULL,
            success TINYINT(1) DEFAULT 0,
            INDEX idx_mobile (mobile),
            INDEX idx_ip (ip),
            INDEX idx_attempt_time (attempt_time)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS ip_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            transaction_id VARCHAR(50) NOT NULL,
            ip VARCHAR(45) NOT NULL,
            user_agent TEXT NULL,
            action VARCHAR(50) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_transaction_id (transaction_id),
            INDEX idx_ip (ip),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    echo "<!DOCTYPE html>
    <html lang='fa' dir='rtl'>
    <head>
        <meta charset='UTF-8'>
        <title>نصب موفق</title>
        <script src='https://cdn.tailwindcss.com'></script>
    </head>
    <body class='bg-gradient-to-br from-green-500 to-emerald-600 min-h-screen flex items-center justify-center p-4'>
        <div class='bg-white p-8 rounded-2xl shadow-2xl max-w-md text-center'>
            <div class='text-6xl mb-4'>✅</div>
            <h1 class='text-2xl font-black text-gray-800 mb-3'>به‌روزرسانی دیتابیس موفق</h1>
            <p class='text-gray-600 mb-6'>تمام جداول با موفقیت ساخته یا به‌روزرسانی شدند</p>
            <div class='bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-6 text-right'>
                <p class='font-bold text-green-800 mb-2'>جداول فعال:</p>
                <ul class='text-sm text-green-700 space-y-1'>
                    <li>✅ transactions</li>
                    <li>✅ messages</li>
                    <li>✅ cards</li>
                    <li>✅ rate_limits</li>
                    <li>✅ settings</li>
                    <li>✅ otp_attempts (جدید)</li>
                    <li>✅ ip_logs (جدید)</li>
                </ul>
            </div>
            <a href='admin.php' class='inline-block mt-3 bg-gray-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-700 transition'>
                🔙 رفتن به پنل مدیریت
            </a>
        </div>
    </body>
    </html>";
    
} catch (Exception $e) {
    echo "<!DOCTYPE html>
    <html lang='fa' dir='rtl'>
    <head>
        <meta charset='UTF-8'>
        <title>خطا در نصب</title>
        <script src='https://cdn.tailwindcss.com'></script>
    </head>
    <body class='bg-gradient-to-br from-red-500 to-pink-600 min-h-screen flex items-center justify-center p-4'>
        <div class='bg-white p-8 rounded-2xl shadow-2xl max-w-md text-center'>
            <div class='text-6xl mb-4'>❌</div>
            <h1 class='text-2xl font-black text-gray-800 mb-3'>خطا در نصب</h1>
            <p class='text-red-600 mb-6'>" . htmlspecialchars($e->getMessage()) . "</p>
            <a href='install.php' class='inline-block bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 transition'>
                🔄 تلاش مجدد
            </a>
        </div>
    </body>
    </html>";
}