<?php
require_once 'config.php';
require_once 'rate_limiter.php';

checkRateLimit();

header('Content-Type: application/json; charset=utf-8');

$sms = $_REQUEST['sms_body'] ?? '';

if (empty($sms)) {
    echo json_encode(['success' => false, 'error' => 'پارامتر sms_body الزامی است'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (strpos($sms, 'واریز پول') === false && strpos($sms, 'واریز') === false) {
    echo json_encode(['success' => false, 'error' => 'این پیامک واریز نیست'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sms = str_replace(['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], ['0','1','2','3','4','5','6','7','8','9'], $sms);
$sms = str_replace(['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'], ['0','1','2','3','4','5','6','7','8','9'], $sms);

$amountRial = 0;
if (preg_match('/([\d,]+)\s*ریال\s*به\s*حساب\s*شما\s*نشست/u', $sms, $m)) {
    $amountRial = (int) str_replace(',', '', $m[1]);
} else {
    echo json_encode(['success' => false, 'error' => 'مبلغ در پیامک یافت نشد'], JSON_UNESCAPED_UNICODE);
    exit;
}

$time = '';
preg_match('/(\d{1,2}:\d{2})/', $sms, $m) ? $time = $m[1] : $time = 'unknown';

$date = '';
preg_match('/(\d{4}\.\d{2}\.\d{2})/', $sms, $m) ? $date = $m[1] : $date = 'unknown';

$msgId = 'MSG_' . time() . '_' . rand(100, 999);

try {
    $db = getDB();
    
    $stmt = $db->prepare("
        INSERT INTO messages (
            msg_id, raw_body, amount_rial, time, date,
            is_deposit, verify, received_at
        ) VALUES (
            :msg_id, :raw_body, :amount_rial, :time, :date,
            1, 0, NOW()
        )
    ");
    
    $stmt->execute([
        ':msg_id' => $msgId,
        ':raw_body' => $sms,
        ':amount_rial' => $amountRial,
        ':time' => $time,
        ':date' => $date
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'پیامک با موفقیت ثبت شد',
        'data' => [
            'msg_id' => $msgId,
            'amount_rial' => $amountRial,
            'time' => $time,
            'date' => $date
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'خطا در ثبت پیامک: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}