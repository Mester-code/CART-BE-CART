<?php
require_once 'config.php';

$txId = $_GET['id'] ?? '';

try {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = :id");
    $stmt->execute([':id' => $txId]);
    $tx = $stmt->fetch();
} catch (Exception $e) {
    $tx = null;
}

if (!$tx) {
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>خطا</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <style>body{font-family:Tahoma,sans-serif}</style>
    </head>
    <body class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-lg p-8 text-center max-w-sm w-full">
            <div class="text-5xl mb-4">⚠️</div>
            <h1 class="text-xl font-bold text-gray-800 mb-2">لینک معتبر نیست</h1>
            <p class="text-gray-500 text-sm">این تراکنش وجود ندارد یا منقضی شده است.</p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

$isExpired = strtotime($tx['expires_at']) < time();
$requiresOtp = ($tx['base_amount_rial'] / 10) >= OTP_THRESHOLD_TOMAN;
$isVerified = !empty($tx['phone_verified']);
$showLockedCard = $requiresOtp && !$isVerified;

$formattedAmount = number_format($tx['final_amount_rial']);
$formattedBaseAmount = number_format($tx['base_amount_rial']);
$formattedCardNumber = chunk_split($tx['card_number'] ?? '', 4, ' ');
$callbackUrl = $tx['callback_url'] ?? '';
$apiKeyForJs = urlencode(API_KEY);

$bankName = strtolower($tx['card_bank'] ?? '');
$cardGradient = 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)';
if (strpos($bankName, 'بلو') !== false || strpos($bankName, 'blu') !== false) {
    $cardGradient = 'linear-gradient(135deg, #0066ff 0%, #0044cc 40%, #002288 100%)';
} elseif (strpos($bankName, 'ملت') !== false) {
    $cardGradient = 'linear-gradient(135deg, #c41e3a 0%, #8b0000 50%, #5c0000 100%)';
} elseif (strpos($bankName, 'سامان') !== false) {
    $cardGradient = 'linear-gradient(135deg, #006400 0%, #004d00 50%, #003300 100%)';
} elseif (strpos($bankName, 'پاسارگاد') !== false) {
    $cardGradient = 'linear-gradient(135deg, #b8860b 0%, #8b6914 50%, #6b4f0a 100%)';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پرداخت | <?php echo $formattedAmount; ?> ریال</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700;900&display=swap');
        * { font-family: 'Vazirmatn', Tahoma, sans-serif; }

        .credit-card {
            width: 100%; aspect-ratio: 1.586;
            background: <?php echo $cardGradient; ?>;
            border-radius: 16px; position: relative; overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.05) inset;
            padding: 24px; display: flex; flex-direction: column; justify-content: space-between;
            color: white; direction: ltr; text-align: left; user-select: none;
        }
        .credit-card::before {
            content: ''; position: absolute; top: -40%; left: -20%; width: 140%; height: 140%;
            background: radial-gradient(ellipse at 30% 20%, rgba(255,255,255,0.12) 0%, transparent 60%); pointer-events: none;
        }
        .chip {
            width: 45px; height: 34px;
            background: linear-gradient(135deg, #f0d68a 0%, #c9a84c 50%, #f0d68a 100%);
            border-radius: 6px; position: relative; box-shadow: 0 1px 3px rgba(0,0,0,0.3);
        }
        .chip::before { content: ''; position: absolute; top: 50%; left: 4px; right: 4px; height: 1px; background: rgba(0,0,0,0.15); }
        .chip::after { content: ''; position: absolute; left: 50%; top: 4px; bottom: 4px; width: 1px; background: rgba(0,0,0,0.15); }
        .card-number { font-family: 'Courier New', monospace; font-size: 20px; letter-spacing: 3px; text-shadow: 0 1px 2px rgba(0,0,0,0.3); font-weight: bold; }
        .card-label { font-size: 9px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.7; margin-bottom: 2px; }

        .fade-up { animation: fadeUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) both; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .fade-up-d1 { animation-delay: 0.1s; } .fade-up-d2 { animation-delay: 0.2s; } .fade-up-d3 { animation-delay: 0.3s; } .fade-up-d4 { animation-delay: 0.4s; }

        .spinner {
            width: 20px; height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #ffffff;
            animation: spin 0.8s linear infinite;
            display: none;
        }
        .spinner-dark {
            width: 20px; height: 20px;
            border: 3px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top-color: #4f46e5;
            animation: spin 0.8s linear infinite;
            display: none;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .pulse-dot { animation: pulseDot 2s ease-in-out infinite; }
        @keyframes pulseDot { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .countdown-num { font-size: 52px; font-weight: 900; line-height: 1; background: linear-gradient(135deg, #10b981, #059669); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }

        .btn-primary { background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
        .btn-primary:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.4); }
        .btn-primary:active:not(:disabled) { transform: translateY(0); }
        .btn-primary:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }

        .btn-success { background: linear-gradient(135deg, #059669 0%, #10b981 100%); transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
        .btn-success:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 10px 25px -5px rgba(16, 185, 129, 0.4); }
        .btn-success:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }

        .copy-btn { transition: all 0.2s; cursor: pointer; }
        .copy-btn:hover { background: rgba(0,0,0,0.05); }
        .copy-btn:active { transform: scale(0.95); }
        .copy-btn.copied { background: #d1fae5 !important; color: #059669 !important; }

        .amount-box { background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); border: 1.5px solid #fbbf24; }
        .timer-box { background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border: 1.5px solid #fca5a5; }

        .toast { transform: translateY(100px); opacity: 0; transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
        .toast.show { transform: translateY(0); opacity: 1; }
        
        .modal-backdrop { background: rgba(0, 0, 0, 0.6); backdrop-filter: blur(4px); }
    </style>
</head>
<body class="bg-gradient-to-b from-gray-50 to-gray-100 min-h-screen flex items-center justify-center p-4">

<div class="w-full max-w-md relative z-10">
    
    <?php if ($tx['status'] === 'paid'): ?>
    <div class="bg-white rounded-2xl shadow-xl p-8 text-center fade-up">
        <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-5">
            <svg class="w-10 h-10 text-green-600" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h2 class="text-2xl font-black text-gray-900 mb-2">پرداخت موفق</h2>
        <p class="text-gray-500 text-sm mb-5">تراکنش شما با موفقیت ثبت و تایید شد</p>
        <div class="bg-green-50 border border-green-200 rounded-xl p-4 mb-5">
            <div class="text-xs text-gray-500 mb-1">مبلغ واریزی</div>
            <div class="text-2xl font-black text-green-700"><?php echo $formattedBaseAmount; ?> <span class="text-sm font-medium">ریال</span></div>
        </div>
        <?php if (!empty($callbackUrl)): ?>
        <div class="bg-gray-50 border border-gray-200 rounded-xl p-5">
            <p class="text-gray-600 text-sm mb-3">در حال انتقال به مقصد...</p>
            <div class="countdown-num" id="paidCountdown">3</div>
            <p class="text-xs text-gray-400 mt-2">ثانیه تا هدایت</p>
        </div>
        <?php endif; ?>
    </div>

    <?php elseif ($isExpired): ?>
    <div class="bg-white rounded-2xl shadow-xl p-8 text-center fade-up">
        <div class="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-5">
            <svg class="w-10 h-10 text-red-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <h2 class="text-2xl font-black text-gray-900 mb-2">لینک منقضی شده</h2>
        <p class="text-gray-500 text-sm mb-5">مهلت پرداخت این تراکنش به پایان رسیده است</p>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4">
            <p class="text-red-700 text-sm font-medium">لطفاً یک تراکنش جدید ایجاد کنید</p>
        </div>
    </div>

    <?php else: ?>
    
    <div class="fade-up fade-up-d1 mb-4">
        <div class="amount-box rounded-xl p-5 text-center">
            <div class="text-xs text-amber-700 font-medium mb-2">مبلغ دقیق قابل پرداخت</div>
            <div class="flex items-center justify-center gap-3">
                <span class="text-3xl font-black text-gray-900 tracking-tight" dir="ltr"><?php echo $formattedAmount; ?></span>
                <span class="text-base font-bold text-amber-700">ریال</span>
            </div>
            <button onclick="copyAmount()" id="copyAmountBtn" class="copy-btn mt-3 mx-auto flex items-center gap-1.5 bg-white/70 border border-amber-300 rounded-lg px-4 py-1.5 text-xs font-bold text-amber-800">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                <span id="copyAmountText">کپی مبلغ</span>
            </button>
            <div class="mt-3 text-xs text-gray-500">⚠️ لطفاً <span class="font-bold text-red-600">دقیقاً</span> همین مبلغ را واریز کنید</div>
        </div>
    </div>

    <div id="lockedCardState" class="<?php echo $showLockedCard ? 'block fade-up fade-up-d2' : 'hidden'; ?>">
        <div class="bg-gray-50 border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center mb-4">
            <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg class="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
            </div>
            <h3 class="font-bold text-gray-700 mb-1">شماره کارت مخفی است</h3>
            <p class="text-xs text-gray-500 mb-4">برای مشاهده شماره کارت مقصد، ابتدا هویت خود را تایید کنید</p>
            <button onclick="openOtpModal()" class="btn-primary w-full text-white p-3.5 rounded-xl font-bold text-base flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>
                دریافت شماره کارت
            </button>
        </div>
    </div>

    <div id="realCardState" class="<?php echo $showLockedCard ? 'hidden' : 'block fade-up fade-up-d2 space-y-4'; ?>">
        <div class="credit-card">
            <div class="flex justify-between items-start relative z-10">
                <div class="chip"></div>
                <div class="text-sm font-medium opacity-90"><?php echo htmlspecialchars($tx['card_bank'] ?? ''); ?></div>
            </div>
            <div class="relative z-10">
                <div class="card-number mb-4"><?php echo $formattedCardNumber; ?></div>
                <div class="flex justify-between items-end">
                    <div>
                        <div class="card-label">Card Holder</div>
                        <div class="text-sm font-medium"><?php echo htmlspecialchars($tx['card_owner'] ?? ''); ?></div>
                    </div>
                    <div class="flex gap-1.5">
                        <div class="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                            <svg class="w-4 h-4 opacity-80" fill="currentColor" viewBox="0 0 24 24"><circle cx="9" cy="12" r="7" opacity="0.6"/><circle cx="15" cy="12" r="7" opacity="0.6"/></svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <button onclick="copyCardNumber()" id="copyCardBtn" class="copy-btn w-full bg-white border border-gray-200 rounded-xl p-3 flex items-center justify-between shadow-sm">
            <div class="flex items-center gap-2">
                <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                <span class="text-sm text-gray-600">کپی شماره کارت</span>
            </div>
            <span id="copyCardText" class="text-xs font-bold text-gray-400">کپی</span>
        </button>
    </div>

    <div class="fade-up fade-up-d3 space-y-4 mt-4">
        <div class="timer-box rounded-xl p-4 flex items-center justify-between">
            <div class="flex items-center gap-2.5">
                <div class="w-2 h-2 rounded-full bg-red-500 pulse-dot"></div>
                <div>
                    <div class="text-xs font-bold text-red-800">زمان باقی‌مانده</div>
                    <div class="text-[10px] text-red-600">تا انقضای تراکنش</div>
                </div>
            </div>
            <div id="countdown" class="text-2xl font-black text-red-600 font-mono tracking-wider" dir="ltr">--:--</div>
        </div>

        <div class="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
            <h4 class="text-sm font-bold text-gray-800 mb-2">مراحل پرداخت:</h4>
            <ol class="text-xs text-gray-600 space-y-1.5 list-none">
                <li class="flex items-start gap-2"><span class="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">۱</span> مبلغ <span class="font-bold mx-1"><?php echo $formattedAmount; ?> ریال</span> را به کارت بالا واریز کنید</li>
                <li class="flex items-start gap-2"><span class="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">۲</span> دکمه «واریز کردم» را بزنید</li>
                <li class="flex items-start gap-2"><span class="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">۳</span> سیستم به صورت خودکار پرداخت شما را تایید می‌کند</li>
            </ol>
        </div>

        <button onclick="checkPaymentStatus()" id="checkBtn" class="btn-success w-full text-white p-4 rounded-xl font-black text-base flex items-center justify-center gap-2.5">
            <span id="checkBtnText">واریز کردم، بررسی کن</span>
            <div class="spinner" id="checkLoader"></div>
        </button>
        <div id="checkMessage" class="text-center text-sm font-medium min-h-[50px]"></div>
    </div>
    <?php endif; ?>

    <div class="text-center mt-6">
        <p class="text-[10px] text-gray-400">پرداخت امن | سیستم پرداخت خودکار</p>
    </div>
</div>

<div id="otpModal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4">
    <div class="absolute inset-0 modal-backdrop transition-opacity" onclick="closeOtpModal()"></div>
    <div class="bg-white rounded-2xl shadow-2xl p-6 relative w-full max-w-sm fade-up z-10">
        <button onclick="closeOtpModal()" class="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
        
        <div class="text-center mb-5">
            <div class="w-14 h-14 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            </div>
            <h2 class="text-lg font-black text-gray-900">تایید هویت امنیتی</h2>
            <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                کاربر گرامی، به دلیل محدودیت‌های امنیتی و جلوگیری از سوءاستفاده، برای انتقال وجه به مبلغ <span class="font-bold text-indigo-600"><?php echo number_format(OTP_THRESHOLD_TOMAN); ?> تومان</span> به بالا، لازم است شماره تلفن همراه خود را تایید نمایید.
            </p>
        </div>

        <div class="space-y-3">
            <input type="tel" id="mobileInput" placeholder="0912 345 6789" maxlength="11" class="w-full p-3.5 border-2 border-gray-200 rounded-xl text-left focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 outline-none transition text-lg tracking-wider" dir="ltr" inputmode="numeric">
            
            <button onclick="sendOtp()" id="sendOtpBtn" class="btn-primary w-full text-white p-3.5 rounded-xl font-bold text-base flex items-center justify-center gap-2">
                <span id="sendOtpText">ارسال کد تایید</span>
                <div class="spinner" id="otpSpinner"></div>
            </button>
            
            <div id="otpCodeSection" class="hidden space-y-3 pt-2 border-t border-gray-100">
                <input type="text" id="otpCodeInput" placeholder="• • • • •" maxlength="5" class="w-full p-3.5 border-2 border-gray-200 rounded-xl text-center tracking-[0.5em] focus:border-green-500 focus:ring-4 focus:ring-green-100 outline-none transition text-2xl font-bold" dir="ltr" inputmode="numeric">
                <button onclick="verifyOtp()" id="verifyOtpBtn" class="btn-success w-full text-white p-3.5 rounded-xl font-bold text-base flex items-center justify-center gap-2">
                    <span id="verifyOtpText">تایید و دریافت شماره کارت</span>
                    <div class="spinner" id="verifySpinner"></div>
                </button>
                <p id="otpAttempts" class="text-center text-xs text-gray-500"></p>
            </div>
            <p id="otpMessage" class="text-center text-sm font-medium min-h-[20px]"></p>
        </div>
    </div>
</div>

<!-- Toast -->
<div id="toast" class="toast fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] px-5 py-2.5 rounded-full shadow-lg font-bold text-sm text-white bg-gray-900">
    <span id="toastMessage"></span>
</div>

<script>
    const txId = '<?php echo $txId; ?>';
    const expiresAt = new Date('<?php echo $tx['expires_at']; ?>').getTime();
    const callbackUrl = <?php echo json_encode($callbackUrl); ?>;
    const txStatus = '<?php echo $tx['status']; ?>';
    const apiKey = '<?php echo $apiKeyForJs; ?>';
    const cardNumber = '<?php echo str_replace(' ', '', $tx['card_number'] ?? ''); ?>';
    const amountText = '<?php echo $formattedAmount; ?>';

    if (txStatus === 'paid' && callbackUrl) {
        let c = 3;
        const el = document.getElementById('paidCountdown');
        if (el) {
            const iv = setInterval(() => {
                el.innerText = c; c--;
                if (c < 0) { clearInterval(iv); window.location.href = callbackUrl; }
            }, 1000);
        }
    }

    if (document.getElementById('countdown')) {
        const timer = setInterval(() => {
            const d = expiresAt - Date.now();
            if (d < 0) { 
                clearInterval(timer); 
                document.getElementById('countdown').innerText = '00:00'; 
                setTimeout(() => location.reload(), 1500); 
            } else {
                const m = Math.floor((d % (1000 * 60 * 60)) / (1000 * 60));
                const s = Math.floor((d % (1000 * 60)) / 1000);
                document.getElementById('countdown').innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            }
        }, 1000);
    }

    function openOtpModal() {
        document.getElementById('otpModal').classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
    function closeOtpModal() {
        document.getElementById('otpModal').classList.add('hidden');
        document.body.style.overflow = '';
    }

    function playCopySound() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain); gain.connect(ctx.destination);
            osc.frequency.value = 800; osc.type = 'sine';
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.1);
        } catch(e) {}
    }

    function copyCardNumber() {
        navigator.clipboard.writeText(cardNumber).then(() => {
            playCopySound();
            showToast('✅ شماره کارت کپی شد', 'success');
            const btn = document.getElementById('copyCardText');
            btn.innerText = 'کپی شد';
            document.getElementById('copyCardBtn').classList.add('copied');
            setTimeout(() => { btn.innerText = 'کپی'; document.getElementById('copyCardBtn').classList.remove('copied'); }, 2000);
        });
    }

    function copyAmount() {
        navigator.clipboard.writeText(amountText).then(() => {
            playCopySound();
            showToast('✅ مبلغ کپی شد', 'success');
            const btn = document.getElementById('copyAmountText');
            btn.innerText = 'کپی شد';
            document.getElementById('copyAmountBtn').classList.add('copied');
            setTimeout(() => { btn.innerText = 'کپی مبلغ'; document.getElementById('copyAmountBtn').classList.remove('copied'); }, 2000);
        });
    }

    let otpAttempts = 0;
    const maxOtpAttempts = 3;

    async function sendOtp() {
        const mobile = document.getElementById('mobileInput').value.trim();
        if (!/^09[0-9]{9}$/.test(mobile)) {
            showToast('❌ شماره موبایل معتبر نیست', 'error');
            return;
        }
        
        const btn = document.getElementById('sendOtpBtn');
        const spinner = document.getElementById('otpSpinner');
        const text = document.getElementById('sendOtpText');
        
        spinner.style.display = 'inline-block';
        text.innerText = 'در حال ارسال...';
        btn.disabled = true;
        
        try {
            const res = await fetch('send_otp.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ mobile: mobile, code: Math.floor(10000 + Math.random() * 90000) })
            });
            const data = await res.json();
            
            if (data.success) {
                document.getElementById('otpCodeSection').classList.remove('hidden');
                btn.style.display = 'none'; // مخفی کردن کامل دکمه ارسال بعد از موفقیت
                showToast('✅ کد تایید ارسال شد', 'success');
                localStorage.setItem('temp_mobile', mobile);
                document.getElementById('otpCodeInput').focus();
                updateOtpAttemptsDisplay();
            } else {
                showToast('❌ ' + (data.error || 'خطا در ارسال پیامک'), 'error');
                spinner.style.display = 'none';
                text.innerText = 'ارسال کد تایید';
                btn.disabled = false;
            }
        } catch (err) {
            showToast('❌ خطا در ارتباط با سرور. اینترنت خود را بررسی کنید.', 'error');
            spinner.style.display = 'none';
            text.innerText = 'ارسال کد تایید';
            btn.disabled = false;
        }
    }

    async function verifyOtp() {
        if (otpAttempts >= maxOtpAttempts) {
            showToast('❌ تعداد تلاش‌ها تمام شد. ۱۵ دقیقه صبر کنید.', 'error');
            document.getElementById('verifyOtpBtn').disabled = true;
            document.getElementById('otpCodeInput').disabled = true;
            document.getElementById('otpAttempts').innerHTML = '<span class="text-red-600 font-bold">⛔ قفل شده - ۱۵ دقیقه دیگر تلاش کنید</span>';
            return;
        }
        
        const code = document.getElementById('otpCodeInput').value.trim();
        const mobile = localStorage.getItem('temp_mobile');
        
        if (!/^\d{5}$/.test(code)) {
            showToast('❌ کد باید ۵ رقم باشد', 'error');
            return;
        }
        
        const btn = document.getElementById('verifyOtpBtn');
        const spinner = document.getElementById('verifySpinner');
        const text = document.getElementById('verifyOtpText');
        
        spinner.style.display = 'inline-block';
        text.innerText = 'در حال بررسی...';
        btn.disabled = true;
        
        try {
            const res = await fetch('verify_otp.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: txId, action: 'verify_otp', mobile: mobile, code: code })
            });
            
            const rawText = await res.text();
            
            let data;
            try {
                data = JSON.parse(rawText);
            } catch (e) {
                throw new Error('پاسخ سرور نامعتبر است (JSON نیست). جزئیات: ' + rawText.substring(0, 200));
            }
            
            if (data.success) {
                showToast('✅ هویت با موفقیت تایید شد', 'success');
                closeOtpModal();
                
                document.getElementById('lockedCardState').classList.add('hidden');
                const realCard = document.getElementById('realCardState');
                realCard.classList.remove('hidden');
                realCard.classList.add('fade-up');
                
            } else {
                otpAttempts++;
                updateOtpAttemptsDisplay();
                
                if (otpAttempts >= maxOtpAttempts) {
                    showToast('❌ تعداد تلاش‌ها تمام شد. ۱۵ دقیقه قفل شدید.', 'error');
                    btn.disabled = true;
                    document.getElementById('otpCodeInput').disabled = true;
                    document.getElementById('otpAttempts').innerHTML = '<span class="text-red-600 font-bold">⛔ قفل شده - ۱۵ دقیقه دیگر تلاش کنید</span>';
                } else {
                    showToast('❌ ' + (data.error || 'کد اشتباه است'), 'error');
                    spinner.style.display = 'none';
                    text.innerText = 'تایید و دریافت شماره کارت';
                    btn.disabled = false;
                    document.getElementById('otpCodeInput').value = '';
                    document.getElementById('otpCodeInput').focus();
                }
            }
        } catch (err) {
            console.error('❌ خطای کامل جاوااسکریپت:', err);
            showToast('❌ ' + err.message, 'error');
            spinner.style.display = 'none';
            text.innerText = 'تایید و دریافت شماره کارت';
            btn.disabled = false;
        }
    }
    function updateOtpAttemptsDisplay() {
        const remaining = maxOtpAttempts - otpAttempts;
        const el = document.getElementById('otpAttempts');
        if (remaining > 0 && !el.innerHTML.includes('قفل')) {
            el.innerHTML = `<span class="text-blue-600">🔑 ${remaining} تلاش باقی‌مانده</span>`;
        }
    }

    async function checkPaymentStatus() {
        const checkBtn = document.getElementById('checkBtn');
        const checkBtnText = document.getElementById('checkBtnText');
        const checkLoader = document.getElementById('checkLoader');
        const checkMessage = document.getElementById('checkMessage');
        
        checkLoader.style.display = 'inline-block';
        checkBtn.disabled = true;
        checkBtnText.innerText = '⏳ در حال جستجو...';
        checkMessage.innerHTML = '<span class="text-blue-600 font-bold">🔍 در حال بررسی تراکنش‌های دریافتی...</span>';
        
        try {
            const url = `verify.php?api_key=${apiKey}&hangt_id=${txId}`;
            const res = await fetch(url);
            const text = await res.text();
            
            let data;
            try { data = JSON.parse(text); } catch (e) { throw new Error('پاسخ نامعتبر از سرور'); }
            
            checkLoader.style.display = 'none';
            
            if (data.status === 'paid') {
                checkBtnText.innerText = '✅ پرداخت تایید شد';
                showToast('✅ پرداخت با موفقیت تایید شد!', 'success');
                if (callbackUrl) {
                    let c = 3;
                    checkMessage.innerHTML = `<div class="bg-green-50 border border-green-200 rounded-xl p-4 mt-2 fade-up"><p class="text-green-800 font-bold mb-2">✅ پرداخت شما شناسایی شد</p><div class="countdown-num">${c}</div><p class="text-xs text-gray-500 mt-2">ثانیه تا هدایت</p></div>`;
                    const iv = setInterval(() => {
                        c--;
                        if (c >= 0) checkMessage.querySelector('.countdown-num').innerText = c;
                        if (c < 0) { clearInterval(iv); window.location.href = callbackUrl; }
                    }, 1000);
                } else {
                    checkMessage.innerHTML = '<span class="text-green-600 font-bold">✅ پرداخت تایید شد. در حال بارگذاری مجدد...</span>';
                    setTimeout(() => location.reload(), 2000);
                }
            } else if (data.status === 'expired') {
                showToast('❌ زمان تراکنش تمام شده', 'error');
                checkMessage.innerHTML = '<span class="text-red-600 font-bold">❌ زمان تراکنش به پایان رسیده است</span>';
                setTimeout(() => location.reload(), 2500);
            } else if (data.status === 'pending') {
                showToast('⏳ هنوز واریزی ثبت نشده', 'warning');
                checkMessage.innerHTML = `<div class="bg-orange-50 border border-orange-200 rounded-xl p-4 mt-2 fade-up"><p class="text-orange-800 font-bold mb-1">⏳ هنوز واریزی شناسایی نشد</p><p class="text-xs text-gray-600">لطفاً مطمئن شوید مبلغ را <b>دقیقاً</b> واریز کرده‌اید.<br>تا ۲ دقیقه دیگر مجدداً این دکمه را بزنید.</p></div>`;
                checkBtn.disabled = false;
                checkBtnText.innerText = 'واریز کردم، دوباره بررسی کن';
            } else if (data.error) {
                showToast('❌ ' + data.error, 'error');
                checkMessage.innerHTML = `<span class="text-red-600 font-bold">❌ خطا: ${data.error}</span>`;
                checkBtn.disabled = false;
                checkBtnText.innerText = 'واریز کردم، بررسی کن';
            }
        } catch (err) {
            showToast('❌ خطا در ارتباط با سرور', 'error');
            checkLoader.style.display = 'none';
            checkMessage.innerHTML = `<span class="text-red-600 font-bold">❌ خطا: ${err.message}</span>`;
            checkBtn.disabled = false;
            checkBtnText.innerText = 'واریز کردم، بررسی کن';
        }
    }

    function showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        document.getElementById('toastMessage').innerText = message;
        toast.className = `toast show fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] px-5 py-2.5 rounded-full shadow-lg font-bold text-sm text-white ${type === 'success' ? 'bg-green-600' : type === 'error' ? 'bg-red-600' : type === 'warning' ? 'bg-orange-600' : 'bg-gray-900'}`;
        setTimeout(() => { toast.classList.remove('show'); }, 3000);
    }

    document.getElementById('mobileInput')?.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendOtp(); });
    document.getElementById('otpCodeInput')?.addEventListener('keypress', (e) => { if (e.key === 'Enter') verifyOtp(); });
</script>
</body>
</html>