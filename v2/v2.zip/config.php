<?php
define('API_KEY', 'YourSuperSecretKey_V2_2026!@#$');
define('ADMIN_PASSWORD', 'admin123');

define('DB_HOST', 'localhost');
define('DB_NAME', 'wqhsbtmy_kbk');
define('DB_USER', 'wqhsbtmy_kbk');
define('DB_PASS', 'Navidi85@');
define('DB_CHARSET', 'utf8mb4');

define('SMS_TOKEN', 'dfed4b470162afb083cc1135d7ecb2c10b42c9c7da8f9b0a8de44b78866a6733');
define('OTP_THRESHOLD_TOMAN', 500000);
define('RATE_LIMIT_REQUESTS', 1000);
define('WEBHOOK_TIMEOUT', 5);

define('BACKUP_DIR', __DIR__ . '/backup');

date_default_timezone_set('Asia/Tehran');

function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die(json_encode([
                'success' => false,
                'error' => 'خطا در اتصال به دیتابیس: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE));
        }
    }
    
    return $pdo;
}

function getCards() {
    $db = getDB();
    $stmt = $db->query("SELECT * FROM cards ORDER BY id");
    return $stmt->fetchAll();
}