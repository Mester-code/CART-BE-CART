<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'), true);

if (($data['action'] ?? '') === 'verify_phone') {
    try {
        $db = getDB();
        
        $stmt = $db->prepare("
            UPDATE transactions 
            SET phone_verified = 1,
                user_mobile = :mobile
            WHERE id = :id
        ");
        
        $stmt->execute([
            ':mobile' => $data['mobile'] ?? '',
            ':id' => $data['id'] ?? ''
        ]);
        
        echo json_encode(['success' => true]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}