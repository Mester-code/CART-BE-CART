<?php
require_once 'config.php';
require_once 'rate_limiter.php';

checkRateLimit();

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['chat_id']) || empty($data['amount']) || empty($data['name'])) {
    echo json_encode(['success' => false, 'error' => 'پارامترهای chat_id، amount و name الزامی هستند'], JSON_UNESCAPED_UNICODE);
    exit;
}

$amount = (int)$data['amount'];
$amountRial = ($data['type'] === 'tmn') ? $amount * 10 : $amount;
$cards = getCards();

if (empty($cards)) {
    echo json_encode(['success' => false, 'error' => 'هیچ کارتی تعریف نشده است'], JSON_UNESCAPED_UNICODE);
    exit;
}

$selectedCard = $cards[array_rand($cards)];
$trackingCode = rand(1, 9999);
$finalAmountRial = $amountRial + $trackingCode;
$expiresAt = time() + 3600;

$txId = 'TX_' . time() . '_' . rand(1000, 9999);

try {
    $db = getDB();
    
    $stmt = $db->prepare("
        INSERT INTO transactions (
            id, chat_id, name, base_amount_rial, final_amount_rial,
            card_number, card_bank, card_owner, status, created_at,
            expires_at, callback_url, phone_verified, created_by
        ) VALUES (
            :id, :chat_id, :name, :base_amount_rial, :final_amount_rial,
            :card_number, :card_bank, :card_owner, 'pending', NOW(),
            FROM_UNIXTIME(:expires_at), :callback_url, 0, 'api'
        )
    ");
    
    $stmt->execute([
        ':id' => $txId,
        ':chat_id' => $data['chat_id'],
        ':name' => $data['name'],
        ':base_amount_rial' => $amountRial,
        ':final_amount_rial' => $finalAmountRial,
        ':card_number' => $selectedCard['number'],
        ':card_bank' => $selectedCard['bank'],
        ':card_owner' => $selectedCard['owner'],
        ':expires_at' => $expiresAt,
        ':callback_url' => $data['callback_url'] ?? null
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'تراکنش ایجاد شد',
        'payment_url' => "pay.php?id={$txId}",
        'callback' => [
            'amount_to_pay_rial' => $finalAmountRial,
            'tracking_code' => $trackingCode,
            'expires_in_minutes' => 60
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'خطا در ایجاد تراکنش: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}