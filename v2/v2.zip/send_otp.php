<?php
require_once 'config.php';
require_once 'rate_limiter.php';

checkRateLimit();

header('Content-Type: application/json; charset=utf-8');


$input = file_get_contents('php://input');
$data = json_decode($input, true);


if (empty($data['mobile']) || empty($data['code'])) {
    echo json_encode([
        'success' => false, 
        'error' => 'شماره موبایل و کد الزامی است'
    ]);
    exit;
}


$userToken = trim(SMS_TOKEN); 
if (empty($userToken) || $userToken === 'YOUR_NET_VISIT_TOKEN_HERE') {
    echo json_encode([
        'success' => false,
        'error' => 'توکن پیامک در پنل مدیریت تنظیم نشده است. لطفاً با پشتیبانی تماس بگیرید.'
    ]);
    exit;
}


$apiUrl = 'https://net-visit.ir/api/sms/otp.php';


$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_ENCODING       => '', 
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $userToken,
        'Accept: application/json'
    ],
    CURLOPT_POSTFIELDS     => json_encode([
        'code'   => (string)$data['code'],
        'mobile' => (string)$data['mobile']
    ])
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    error_log("cURL Error in send_otp.php: " . $curlError);
}

if ($response === false || !empty($curlError)) {
    echo json_encode([
        'success' => false,
        'error' => 'خطا در ارتباط با سرور پیامک. لطفاً دوباره تلاش کنید.'
    ]);
    exit;
}

$result = json_decode($response, true);

if (json_last_error() !== JSON_ERROR_NONE || !is_array($result)) {
    error_log("Invalid JSON response from SMS API: " . $response);
    echo json_encode([
        'success' => false,
        'error' => 'پاسخ نامعتبر از سرویس پیامک'
    ]);
    exit;
}

if ($httpCode === 200 && isset($result['success']) && $result['success'] === true) {
    $message = $result['message'] ?? 'کد تایید با موفقیت ارسال شد';
    echo json_encode([
        'success' => true,
        'message' => $message,
        'code' => $result['code'] ?? null
    ]);
} else {
    $errorCode = $result['code'] ?? 'unknown';
    $errorMsg = 'خطای ناشناخته';
    
    switch ((int)$errorCode) {
        case 2:
            $errorMsg = 'موجودی پنل پیامک کافی نیست';
            break;
        case 4:
            $errorMsg = 'خطا در سرویس پیامک (ممکن است الگوی پیامک تایید نشده باشد)';
            break;
        case 5:
            $errorMsg = 'توکن پنل پیامک نامعتبر یا منقضی شده است';
            break;
        case 6:
            $errorMsg = 'شماره موبایل نامعتبر است';
            break;
        default:
            $errorMsg = $result['message'] ?? "خطا در ارسال کد تایید (کد خطا: {$errorCode})";
            break;
    }
    
    if ($errorCode === 'unknown' || $errorCode === 4) {
        error_log("SMS API Error Response: " . $response);
    }
    
    echo json_encode([
        'success' => false,
        'error' => $errorMsg,
        'code' => $errorCode
    ]);
}