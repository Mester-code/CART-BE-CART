<?php

header('Content-Type: application/json; charset=utf-8');

try {
    require_once 'config.php';
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'خطا در بارگذاری تنظیمات: ' . $e->getMessage()]);
    exit;
}

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (($data['action'] ?? '') !== 'verify_otp') {
    echo json_encode(['success' => false, 'error' => 'اکشن نامعتبر است']);
    exit;
}

$txId = $data['id'] ?? '';
$mobile = $data['mobile'] ?? '';
$code = $data['code'] ?? '';
$ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if (empty($txId) || empty($mobile) || empty($code)) {
    echo json_encode(['success' => false, 'error' => 'پارامترها ناقص هستند']);
    exit;
}

try {
    $pdo = getDB();
    
        $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM otp_attempts 
        WHERE mobile = :mobile 
        AND success = 0 
        AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    ");
    $stmt->execute([':mobile' => $mobile]);
    $failedAttempts = $stmt->fetchColumn();
    
    if ($failedAttempts >= 3) {
        echo json_encode([
            'success' => false, 
            'error' => 'تعداد تلاش‌ها بیش از حد مجاز است. ۱۵ دقیقه صبر کنید.',
            'locked' => true
        ]);
        exit;
    }
    

    $stmt = $pdo->prepare("
        INSERT INTO otp_attempts (mobile, ip, attempt_time, success) 
        VALUES (:mobile, :ip, NOW(), 1)
    ");
    $stmt->execute([':mobile' => $mobile, ':ip' => $ip]);
    
        $stmt = $pdo->prepare("
        UPDATE transactions 
        SET phone_verified = 1, user_mobile = :mobile
        WHERE id = :id
    ");
    $stmt->execute([':mobile' => $mobile, ':id' => $txId]);
    
    echo json_encode(['success' => true, 'message' => 'هویت با موفقیت تایید شد']);
    
} catch (Exception $e) {
   error_log("verify_otp.php Error: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    
    echo json_encode([
        'success' => false, 
        'error' => 'خطای داخلی سرور: ' . $e->getMessage()
    ]);
}