<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $db = getDB();
    $now = time();
    $matchedCount = 0;
    $details = [];
    
    $db->prepare("
        UPDATE transactions 
        SET status = 'expired' 
        WHERE status = 'pending' AND expires_at < NOW()
    ")->execute();
    
    $stmt = $db->prepare("
        SELECT * FROM messages 
        WHERE verify = 0 AND is_deposit = 1
        ORDER BY received_at ASC
    ");
    $stmt->execute();
    $messages = $stmt->fetchAll();
    
    foreach ($messages as $msg) {
        $stmt = $db->prepare("
            SELECT * FROM transactions 
            WHERE status = 'pending' 
            AND final_amount_rial = :amount
            AND expires_at > NOW()
            ORDER BY created_at ASC
            LIMIT 1
        ");
        $stmt->execute([':amount' => $msg['amount_rial']]);
        $tx = $stmt->fetch();
        
        if ($tx) {

            $db->prepare("
                UPDATE transactions 
                SET status = 'paid', 
                    paid_at = NOW(),
                    matched_msg_id = :msg_id
                WHERE id = :tx_id
            ")->execute([
                ':msg_id' => $msg['msg_id'],
                ':tx_id' => $tx['id']
            ]);

            $db->prepare("
                UPDATE messages 
                SET verify = 1,
                    matched_hangt_id = :tx_id
                WHERE msg_id = :msg_id
            ")->execute([
                ':tx_id' => $tx['id'],
                ':msg_id' => $msg['msg_id']
            ]);
            
            $matchedCount++;
            $details[] = "تراکنش {$tx['id']} کاربر {$tx['name']} با مبلغ {$msg['amount_rial']} ریال تایید شد.";
            
            if (!empty($tx['callback_url'])) {
                $payload = [
                    'event' => 'payment_success',
                    'transaction_id' => $tx['id'],
                    'amount_rial' => $tx['final_amount_rial'],
                    'card_number' => $tx['card_number'],
                    'paid_at' => date('Y-m-d H:i:s'),
                    'user_mobile' => $tx['user_mobile']
                ];
                
                $ch = curl_init($tx['callback_url']);
                curl_setopt_array($ch, [
                    CURLOPT_POST => true,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => WEBHOOK_TIMEOUT,
                    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
                    CURLOPT_POSTFIELDS => json_encode($payload)
                ]);
                curl_exec($ch);
                curl_close($ch);
            }
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => $matchedCount > 0 
            ? "{$matchedCount} تراکنش با موفقیت مچ و تایید شد."
            : "هیچ تطابق جدیدی یافت نشد.",
        'details' => $details
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'خطا: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}